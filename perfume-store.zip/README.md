# Rosa Perfumes

Site de vendas de perfumes e cosméticos com integração direta com WhatsApp.

## Como Usar

1. Acesse o site através do link: [https://rosa-perfumes.github.io](https://rosa-perfumes.github.io)
2. Navegue pelos produtos disponíveis
3. Faça pedidos direto pelo WhatsApp
4. Use o formulário de pedidos especiais para produtos não listados

## Funcionalidades

- Catálogo de perfumes e cosméticos
- Integração direta com WhatsApp para compras
- Formulário de pedidos especiais
- Design responsivo para desktop e mobile
- Preços atualizados
